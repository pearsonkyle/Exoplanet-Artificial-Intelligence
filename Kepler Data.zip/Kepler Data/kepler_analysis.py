import matplotlib.pyplot as plt
from os import remove, mkdir
from subprocess import call
import pandas as pd
from astropy.io import fits as pf
import numpy as np
import pickle


class kepler_data(object):
    def __init__(self):
        kdata = pd.read_csv('koi_cumulative.csv') # downloaded from NASA website
        self.kcmds = pickle.load(open('kepid_cmds.pkl','rb')) # from "create_download_table.py" and "Kepler_confirmed_wget.bat"

        # filter the data
        f1 = (kdata['koi_disposition'] == 'CONFIRMED') & (kdata['koi_pdisposition'] == 'CANDIDATE')
        self.kdata = kdata[f1]

    def download_lc(self,kepid,i=0):
        subset = self.kcmds[ self.kcmds['kepid']==kepid ]

        # download all quarters of the data
        if i == -1:
            fnames = []
            for j in range(subset.shape[0]):
                cmd = subset['cmds'].as_matrix()[j]
                fname = subset['fnames'].as_matrix()[j]; fnames.append(fnames)
                log = subset['logs'].as_matrix()[j]
                call(cmd,shell=True) # download kepler light curve
                remove(log)
            return fnames

        else:
            cmd = subset['cmds'].as_matrix()[i]
            fname = subset['fnames'].as_matrix()[i]
            log = subset['logs'].as_matrix()[i]
            call(cmd,shell=True) # download kepler light curve
            remove(log)

            return fname

    def get_value(self,name,key):
        return self.kdata[self.kdata.kepler_name==name][key].as_matrix()[0]

    def open_file(self,fname,fluxonly=False,delete=False):
        hdu = pf.open(fname)

        if delete:
            remove(fname)

        if fluxonly:
            time = hdu[1].data['TIME']
            flux = hdu[1].data['PDCSAP_FLUX']
            hdu.close()
            return time,flux
        else:
            return hdu


if __name__ == "__main__":

    newdata = pickle.load(open('kepler_lightcurve_analytics.pkl','rb'))
    scatter = 1e6*np.array(newdata['avgstd'])/np.array(newdata['avgflux'])
    mag = np.array(newdata['koi_kepmag'])
    t14 = np.array(newdata['koi_duration']) # hr
    per = np.array(newdata['koi_period']) # day
    dep = np.array(newdata['koi_depth']) # (Rp/Rs)^2 ppm
    err = np.array(newdata['koi_depth_err1'])


    # 50% features, 15 min cadence
    # 45 hr window, 180pts
    # tdur 3.75-15 hr
    # filter, 2 <= dep/scatter, t14>8
    f_dur = (t14 > 7) & (t14 < 15) & (per < 50)
    f_dep = dep > 2*scatter
    f = f_dur & f_dep

    names = np.array(newdata['kepler_name'])[f]
    depths = dep[f]
    t14s = t14[f]
    ids = np.array(newdata['kepid'])[f]
    pers = per[f]
    kepler = kepler_data()
