import pandas as pd
import numpy as np
import pickle 

FILE = 'Kepler_confirmed_wget.bat'
SKIPLINES = 9
TYPE = 'fits' # or tbl

# read in file 
lines = [line.rstrip('\n') for line in open(FILE)]

kepid = [] # kepler ids
cmds = [] # wget commands 
fnames = [] # file names
logs = [] # log file from downloading

# create data set
for i in range(SKIPLINES,len(lines)):
    
    if lines[i].split('lc.')[1].split("' 'http")[0] == TYPE:
        kepid.append( np.int(lines[i].split('kplr0')[1].split('-')[0]) ) 
        cmds.append( lines[i] )
        fnames.append( lines[i].split("'")[1] )
        logs.append( lines[i].split("'")[-1].split(" ")[-1] ) 

s = pd.DataFrame( {'kepid':kepid,'cmds':cmds,'fnames':fnames,'logs':logs} )
pickle.dump(s,open('kepid_cmds.pkl','wb'))
